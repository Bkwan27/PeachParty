#include "Actor.h"
#include "StudentWorld.h"
#include <iostream>
#include <list>
using namespace std;

void Actor::doSomething() {}

void Square::doSomething() {
	if (!isAlive()) {
		return;
	}
}

int Square::landOnSquare(Avatar* player) {
	Avatar* peach = player;
	if (peach->getX() == getX() && peach->getY() == getY() && peach->onSquare() && !(peach->isWalking())) {
		if (peach->didMove()) {
			return 0; //if it is a newPlayer
		}
		else
			return 1; //if it is not a new Player but on Square
	}
	else if (peach->getX() == getX() && peach->getY() == getY() && peach->onSquare() && (peach->isWalking()))
		return 2; //if it is passing over the Square
	return 3; //if it is not on the Square
}

void CoinSquare::doSomething() {
	Avatar* peach = getWorld()->getPeach();
	Avatar* yoshi = getWorld()->getYoshi();
	
	Square::doSomething();
	if (landOnSquare(peach) == 0 && isBlue()) {
		peach->addCoins(3);
		getWorld()->playSound(SOUND_GIVE_COIN); 
	}
	else if (landOnSquare(peach) == 0 && !isBlue()) {
		peach->addCoins(-3);
		getWorld()->playSound(SOUND_TAKE_COIN);
	}

	if (landOnSquare(yoshi) == 0 && isBlue()) {
		yoshi->addCoins(3);
		getWorld()->playSound(SOUND_GIVE_COIN);
	}
	else if (landOnSquare(yoshi) == 0 && !isBlue()) {
		yoshi->addCoins(-3);
		getWorld()->playSound(SOUND_TAKE_COIN);
	}
}

void DirectionalSquare::doSomething() {
	Avatar* peach = getWorld()->getPeach();
	Avatar* yoshi = getWorld()->getYoshi();

	Square::doSomething();
	if (landOnSquare(peach) < 3) {
		peach->setWalkDirection(forcingDir);
		if (forcingDir == left)
			peach->setDirection(left);
		else
			peach->setDirection(right);
		peach->setOnDirect(true);
	}

	if (landOnSquare(yoshi) < 3) {
		yoshi->setWalkDirection(forcingDir);
		if (forcingDir == left)
			yoshi->setDirection(left);
		else
			yoshi->setDirection(right);
		yoshi->setOnDirect(true);
	}
}

void StarSquare::doSomething() {
	Avatar* peach = getWorld()->getPeach();
	Avatar* yoshi = getWorld()->getYoshi();

	if (landOnSquare(peach) == 1) {
		if (peach->getCoins() < 20)
			return;
		peach->addCoins(-20);
		peach->addStars(1);
		getWorld()->playSound(SOUND_GIVE_STAR);
	}

	if (landOnSquare(yoshi) == 1) {
		if (yoshi->getCoins() < 20)
			return;
		yoshi->addCoins(-20);
		yoshi->addStars(1);
		getWorld()->playSound(SOUND_GIVE_STAR);
	}
}

void BankSquare::doSomething() {
	Avatar* peach = getWorld()->getPeach();
	Avatar* yoshi = getWorld()->getYoshi();

	if (landOnSquare(peach) == 1) {
		peach->addCoins(getWorld()->getBalance());
		getWorld()->addToBank(-(getWorld()->getBalance()));
		getWorld()->playSound(SOUND_WITHDRAW_BANK);
	}
	else if (landOnSquare(peach) == 2) {
		if (peach->getCoins() < 5)
			getWorld()->addToBank(peach->setCoins(0));
		else {
			peach->addCoins(-5);
			getWorld()->addToBank(5);
		}
		getWorld()->playSound(SOUND_DEPOSIT_BANK);
	}
}

void EventSquare::doSomething() {
	Avatar* peach = getWorld()->getPeach();
	Avatar* yoshi = getWorld()->getYoshi();

	if (landOnSquare(peach) == 1) {
		int rand = randInt(2, 2);
		switch (rand) {
		case 1:
			peach->teleport(-1, -1);
			getWorld()->playSound(SOUND_PLAYER_TELEPORT);
			peach->walked(true);
			break;
		case 2:
			if (!(peach->getWasOnEvent())) {
				peach->teleport(yoshi->getX(), yoshi->getY());
				getWorld()->playSound(SOUND_PLAYER_TELEPORT);
			}
			//if (!(peach->getWasOnEvent()))
				peach->walked(true);
			break;
		}
	}
}

bool Mover::multipleDir() {
	int x = getX();
	int y = getY();
	Board game = getWorld()->getBoard();
	int newX1 = 0, newX2 = 0, newY1 = 0, newY2 = 0;
	int possible = 0;
	if (m_walkDirection == left) {
		newY1 = y + 16;
		newY2 = y - 16;
		newX1 = x - 16;
		if (game.getContentsOf(x / 16, newY1 / 16) != Board::empty)
			possible++;
		if (game.getContentsOf(x / 16, newY2 / 16) != Board::empty)
			possible++;
		if (game.getContentsOf(newX1 / 16, y / 16) != Board::empty)
			possible++;
	}

	if (m_walkDirection == right) {
		newY1 = y + 16;
		newY2 = y - 16;
		newX1 = x + 16;
		if (game.getContentsOf(x / 16, newY1 / 16) != Board::empty)
			possible++;
		if (game.getContentsOf(x / 16, newY2 / 16) != Board::empty)
			possible++;
		if (game.getContentsOf(newX1 / 16, y / 16) != Board::empty)
			possible++;
	}

	if (m_walkDirection == up) {
		newX1 = x + 16;
		newX2 = x - 16;
		newY1 = y + 16;
		if (game.getContentsOf(newX1 / 16, y / 16) != Board::empty)
			possible++;
		if (game.getContentsOf(newX2 / 16, y / 16) != Board::empty)
			possible++;
		if (game.getContentsOf(x / 16, newY1 / 16) != Board::empty)
			possible++;
	}

	if (m_walkDirection == down) {
		newX1 = x + 16;
		newX2 = x - 16;
		newY1 = y - 16;
		if (game.getContentsOf(newX1 / 16, y / 16) != Board::empty)
			possible++;
		if (game.getContentsOf(newX2 / 16, y / 16) != Board::empty)
			possible++;
		if (game.getContentsOf(x / 16, newY1 / 16) != Board::empty)
			possible++;
	}

	if (possible > 1) {
		return true;
	}

	return false;

}

void Mover::doSomething() {
	int x = getX();
	int y = getY();
	Board game = getWorld()->getBoard();
	int dir = m_walkDirection;
	int newX, newY;

	if (m_walking) {
		switch (dir) {
		case left:
			x -= 16;
			break;
		case right:
			x += 16;
			break;
		case up:
			y += 16;
			break;
		case down:
			y -= 16;
			break;
		}

		newX = x / 16;
		newY = y / 16;
		if (onSquare() && multipleDir() && didWalk) {
			
		}
		else if (game.getContentsOf(newX, newY) == Board::empty && onSquare()) {
			if (dir == right || dir == left) {
				bool up1 = true, down1 = true;
				x = getX();
				y = getY();
				newX = x;
				newY = y + 16;
				if (game.getContentsOf(newX / 16, newY / 16) == Board::empty)
					up1 = false;
				newY = y - 16;
				if (game.getContentsOf(newX / 16, newY / 16) == Board::empty)
					down1 = false;

				if (up1 && down1)
				{
					setDirection(right);
					m_walkDirection = up;
				}
				else if (up1) {
					setDirection(right);
					m_walkDirection = up;
				}
				else {
					setDirection(right);
					m_walkDirection = down;
				}

			}
			else {
				bool left1 = true, right1 = true;
				y = getY();
				x = getX();
				newX = x - 16;
				newY = y;
				if (game.getContentsOf(newX / 16, newY / 16) == Board::empty)
					left1 = false;
				newX = x + 16;
				if (game.getContentsOf(newX / 16, newY / 16) == Board::empty)
					right1 = false;

				if (left1 && right1)
				{
					setDirection(right);
					m_walkDirection = right;
				}
				else if (right1) {
					setDirection(right);
					m_walkDirection = right;
				}
				else {
					setDirection(left);
					m_walkDirection = left;
				}
			}
		}
		int moveX, moveY;
		getPositionInThisDirection(m_walkDirection, 2, moveX, moveY);
		moveTo(moveX, moveY);
		didWalk = true;
		atStart = false;
		m_ticks -= 1;
	}
}

void Avatar::doSomething() {
	if (!Mover::isWalking()) {
		int key = getWorld()->getAction(m_playerNum);
		Actor* fire;
		switch (key) {
			int roll;
		case ACTION_ROLL:
			roll = randInt(1, 10);
			Mover::changeTicks(roll * 8);
			Mover::setWalking(true);
			Mover::walked(false);
			break;
		case ACTION_FIRE:
			if (hasVortex) {
				fire = new Vortex(getWorld(), getX(), getY(), getWalkDireciton());
				getWorld()->addToActors(fire);
				getWorld()->playSound(SOUND_PLAYER_FIRE);
				hasVortex = false;
			}
			break;
		default:
			Mover::walked(false);
			return;
		} 
	}

	if (isWalking()) {
		Board game = getWorld()->getBoard();
		int x = getX();
		int y = getY();
		if (onSquare() && Mover::multipleDir() && !atBegin() && !onDirectional && didMove()) {
			int key = getWorld()->getAction(m_playerNum);
			if (key == ACTION_DOWN || key == ACTION_UP || key == ACTION_RIGHT || key == ACTION_LEFT) {
				cerr << "in if" << endl;
				if (key == ACTION_DOWN || key == KEY_PRESS_DOWN) {
					cerr << "activated" << endl;
					if (getWalkDireciton() != up && game.getContentsOf(x / 16, (y - 16) / 16) != Board::empty) {
						cerr << "here" << endl;
						setWalkDirection(down);
						setDirection(right);
					}
					else
						return;
				}
				if (key == ACTION_UP || key == KEY_PRESS_UP) {
					cerr << "activated" << endl;
					if (getWalkDireciton() != down && game.getContentsOf(x / 16, (y + 16) / 16) != Board::empty) {
						cerr << "here" << endl;
						setWalkDirection(up);
						setDirection(right);
					}
					else
						return;
				}
				if (key == ACTION_RIGHT || key == KEY_PRESS_RIGHT) {
					cerr << "activated" << endl;
					if (getWalkDireciton() != left && game.getContentsOf((x + 16) / 16, y / 16) != Board::empty) {
						cerr << "here" << endl;
						setWalkDirection(right);
						setDirection(right);
					}
					else
						return;
				}
				if (key == ACTION_LEFT || key == KEY_PRESS_LEFT) {
					cerr << "activated" << endl;
					if (getWalkDireciton() != right && game.getContentsOf((x - 16) / 16, y / 16) != Board::empty) {
						cerr << "here" << endl;
						setWalkDirection(left);
						setDirection(left);
					}
					else
						return;
				}
			}
			else
				return;
		}
	}
	Mover::doSomething();
	onDirectional = false;
	wasOnEvent = false;
	if (Mover::getTicks() == 0) {
		Mover::setWalking(false);
	}
}

void Avatar::teleport(int x, int y) {
	Actor* randomSquare;
	Avatar* other;
	if (m_playerNum == 1)
		other = getWorld()->getYoshi();
	else
		other = getWorld()->getPeach();
	if (x < 0 || y < 0) {
		randomSquare = getWorld()->getRandomSquare();
		moveTo(randomSquare->getX(), randomSquare->getY());
	}
	else {
		int oldX = getX(), oldY = getY();
		moveTo(x, y);
		other->walked(false);
		other->moveTo(oldX, oldY);

		int ticks = getTicks();
		setTicks(other->getTicks());
		other->setTicks(ticks);

		int dir = getWalkDireciton();
		setWalkDirection(other->getWalkDireciton());
		other->setWalkDirection(dir);

		int sprite = getDirection();
		setDirection(other->getDirection());
		other->setDirection(sprite);

		int walking = isWalking();
		setWalking(other->isWalking());
		other->setWalking(walking);

		wasOnEvent = true;
	}
}

void Vortex::doSomething() {
	if (isAlive()) {
		int moveX = 0, moveY = 0;
		getPositionInThisDirection(direction, 2, moveX, moveY);
		moveTo(moveX, moveY);
		if (getX() < 0 || getX() >= VIEW_WIDTH || getY() < 0 || getY() >= VIEW_HEIGHT) {
			cerr << "setting dead" << endl;
			setDead();
		}

		//need to do impact on Bowser and Boo and any actor that is impacted
	}
}

bool Villain::getRandomDir() {
	int dir = randInt(1, 4);
	Board game = getWorld()->getBoard();
	int x = getX();
	int y = getY();
	switch (dir) {
	case 1:
		if (game.getContentsOf((x - 16) / 16, y / 16) != Board::empty) {
			setDirection(left);
			setWalkDirection(left);
			return true;
		}
		return false;
		break;
	case 2:
		if (game.getContentsOf((x + 16) / 16, y / 16) != Board::empty) {
			setDirection(right);
			setWalkDirection(right);
			return true;
		}
		break;
	case 3:
		if (game.getContentsOf(x / 16, (y + 16) / 16) != Board::empty) {
			setDirection(right);
			setWalkDirection(up);
			return true;
		}
		return false;
		break;
	case 4:
		if (game.getContentsOf(x / 16, (y - 16) / 16) != Board::empty) {
			setDirection(right);
			setWalkDirection(down);
			return true;
		}
		return false;
		break;
	}

}

void Villain::doSomething() {
	if (!isWalking()) {
		pauseCounter--;
		if (pauseCounter <= 0) {
			travelDistance = randInt(1, 10);
			changeTicks(travelDistance * 8);
			bool randDir = false;
			while (randDir == false) {
				randDir = getRandomDir();
			}

			setWalking(true);
		}
	}

	if (isWalking()) {
		if (onSquare() && multipleDir() && !atBegin()) {
			bool randDir = false;
			while (randDir == false) {
				randDir = getRandomDir();
			}
		}
		Mover::doSomething();
		if (getTicks() == 0) {
			setWalking(false);
			pauseCounter = 180;
			int rand = randInt(1, 4);
			if (rand == 1) {
				//create Dropping Square and implement it here
			}
		}
	}
}

void Bowser::doSomething() {
	Avatar* peach = getWorld()->getPeach();
	Avatar* yoshi = getWorld()->getYoshi();

	if (!isWalking()) {
		if (peach->getX() == getX() && peach->getY() == getY() && peach->onSquare() && onSquare() && !peach->isWalking()) {
			int chance = randInt(1, 2);
			if (chance == 1) {
				peach->setCoins(0);
				getWorld()->playSound(SOUND_BOWSER_ACTIVATE);
			}
		}

		if (yoshi->getX() == getX() && yoshi->getY() == getY() && yoshi->onSquare() && onSquare() && !yoshi->isWalking()) {
			int chance = randInt(1, 2);
			if (chance == 1) {
				yoshi->setCoins(0);
				getWorld()->playSound(SOUND_BOWSER_ACTIVATE);
			}
		}
	}
	Villain::doSomething();
}

void Boo::doSomething() {
	Avatar* peach = getWorld()->getPeach();
	Avatar* yoshi = getWorld()->getYoshi();

	if (!isWalking()) {
		int rand = randInt(1, 2);
		if (peach->getX() == getX() && peach->getY() == getY() && peach->onSquare() && onSquare() && !peach->isWalking()) {
			if (rand == 1) {
				int coins = yoshi->getCoins();
				yoshi->setCoins(peach->getCoins());
				peach->setCoins(coins);
			}
			else {
				int stars = yoshi->getStars();
				yoshi->setStars(peach->getStars());
				peach->setStars(stars);
			}
			getWorld()->playSound(SOUND_BOO_ACTIVATE);
		}

		if (yoshi->getX() == getX() && yoshi->getY() == getY() && yoshi->onSquare() && onSquare() && !yoshi->isWalking()) {
			rand = randInt(1, 2);
			if (rand == 1) {
				int coins = yoshi->getCoins();
				yoshi->setCoins(peach->getCoins());
				peach->setCoins(coins);
			}
			else {
				int stars = yoshi->getStars();
				yoshi->setStars(peach->getStars());
				peach->setStars(stars);
			}
			getWorld()->playSound(SOUND_BOO_ACTIVATE);
		}
	}

	Villain::doSomething();
}

// Students:  Add code to this file, Actor.h, StudentWorld.h, and StudentWorld.cpp
